from flask import Flask, jsonify
import pandas as pd
import os

app = Flask(__name__)

BASE_DIR = os.path.dirname(__file__)

students = pd.read_csv(os.path.join(BASE_DIR, "..", "data", "students.csv"))
jobs = pd.read_csv(os.path.join(BASE_DIR, "..", "data", "jobs.csv"))

skills = [
    "Python",
    "SQL",
    "Flask",
    "Machine_Learning",
    "Communication"
]

@app.route("/api/explain/<int:student_id>", methods=["GET"])
def explain_match(student_id):

    student = students[students["student_id"] == student_id]

    if student.empty:
        return jsonify({"error": "Student not found"}), 404

    student = student.iloc[0]

    results = []

    for _, job in jobs.iterrows():

        score = 0
        explanation = []

        for skill in skills:

            if student[skill] >= job[skill]:
                score += int(job[skill])
                explanation.append(
                    f"{skill}: matched ({int(student[skill])}/{int(job[skill])})"
                )
            else:
                explanation.append(
                    f"{skill}: below requirement ({int(student[skill])}/{int(job[skill])})"
                )

        if student["Experience"] >= job["Experience"]:
            score += 50
            explanation.append("Experience requirement satisfied")
        else:
            explanation.append("Experience requirement not satisfied")

        if student["Location"] == job["Location"]:
            score += 30
            explanation.append("Location matched")
        else:
            explanation.append("Location different")

        if score >= 450:
            recommendation = "Highly Recommended"
        elif score >= 400:
            recommendation = "Recommended"
        else:
            recommendation = "Can Apply"

        results.append({
            "job_id": int(job["job_id"]),
            "company": str(job["company"]),
            "role": str(job["role"]),
            "match_score": int(score),
            "recommendation": recommendation,
            "explanation": explanation
        })

    results = sorted(results, key=lambda x: x["match_score"], reverse=True)

    return jsonify({
        "student_id": int(student_id),
        "matches": results
    })

if __name__ == "__main__":
    app.run(debug=True)